<?php declare(strict_types = 1);

namespace Drupal\moodle_sync_category\Form;

use Drupal\Core\Url;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\moodle_sync_category\Controller\MoodleSyncCategoryController;
use Drupal\moodle_sync_category\Service\SettingsFormOptionsService;
use Symfony\Component\DependencyInjection\ContainerInterface;

class MoodleSyncCategorySettingsForm extends ConfigFormBase {

  protected $settingsFormOptionsService;

   /**
   * {@inheritdoc}
   */
  public function __construct(
      ConfigFactoryInterface $configFactory,
      SettingsFormOptionsService $settings_form_options_service) {
    parent::__construct($configFactory);
    $this->settingsFormOptionsService = $settings_form_options_service;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    // Instantiates this form class.
    return new static(
      $container->get('config.factory'),
      $container->get('settings_form_options'),
    );
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      'moodle_sync_category.settings',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'moodle_sync_category_settings';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

    $config = $this->config('moodle_sync_category.settings');

    // Taxonomy Settings Form
    $form['taxonomy_settings'] = [
      '#type' => 'details',
      '#open' => TRUE,
      '#title' => $this->t('Taxonomy Settings'),
    ];

    // Dropdown selection shows all taxonomy vocabularies
    $form['taxonomy_settings']['taxonomy_select'] = [
      '#type' => 'select',
      '#title' => $this->t('Select a Taxonomy'),
      '#options' => $this->settingsFormOptionsService->getTaxonomyOptions(),
      '#default_value' => $config->get('selected_taxonomy_term'),
      '#suffix' => '<div class="fieldset__description">' . $this->t('Select the vocabulary that will be synced into Moodle course categories.<br>
                                  The vocabulary must have a <b>field_moodle_id</b> to hold the Moodle ID.') . "</div>",
      '#required' => TRUE,
    ];

    // Delete Settings Form
    $form['delete_settings'] = [
      '#type' => 'details',
      '#open' => TRUE,
      '#title' => $this->t('Delete Settings'),
    ];

    // Trashbin ID.
    $form['delete_settings']['moodle_trashbin_id'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Moodle Trashbin ID'),
      '#default_value' => $config->get('moodle_trashbin_id'),
      '#suffix' => '<div class="fieldset__description">' . $this->t('ID of a Moodle course category where deleted categories will be moved into.') . "</div>",
    ];

    // Sync All
    $form['sync'] = [
      '#type' => 'details',
      '#open' => TRUE,
      '#title' => $this->t('Manual sync'),
      '#description' => $this->t('Sync all existing Categories to Moodle.'),
    ];

    // Button to sync all existing category terms.
    $form['sync']['update_all_categories'] = [
      '#type' => 'link',
      '#title' => $this->t('Sync all Categories to Moodle'),
      '#url' => Url::fromRoute('moodle_sync_category.sync_all_categories'),
      '#attributes' => [
        'class' => ['button'],
      ],
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state): void {
    $this->config('moodle_sync_category.settings')
      ->set('selected_taxonomy_term', $form_state->getValue('taxonomy_select'))
      ->set('moodle_trashbin_id', $form_state->getValue('moodle_trashbin_id'))
      ->save();
    parent::submitForm($form, $form_state);
  }

}